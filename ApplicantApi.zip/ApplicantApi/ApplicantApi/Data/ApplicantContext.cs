﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ApplicantApi.Models;
using Microsoft.EntityFrameworkCore;

namespace ApplicantApi.Data
{
    public class ApplicantContext : DbContext
    {
        public ApplicantContext(DbContextOptions<ApplicantContext> options) : base(options)
        {

        }

        public virtual DbSet<Applicant> Applicants { get; set; }
        public virtual DbSet<Address> Addresses { get; set; }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            //EntityFrameworkCore\Update-Database
            //use the command above if more than one Assembly is removed
            builder.Entity<Applicant>().HasKey(e => e.Id);
            builder.Entity<Address>().HasOne(b => b.Applicant).WithMany(e => e.Addresses).HasForeignKey(e => e.ApplicantID);
            //builder.Entity<Address>().ToTable("Locations");
        }

        //protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        //{
        //    optionsBuilder.UseNpgsql("");
        //}
    }
}
