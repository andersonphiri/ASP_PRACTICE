﻿using ApplicantApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ApplicantApi.Data
{
    public static class DbInitializer
    {
        public static async void Initialize(ApplicantContext context)
        {
            //initialize Applicants
            if (context.Applicants.Any())
            {
                return;
            }

            var applicants = new Applicant[] 
            {
                new Applicant{Name="Anderson", Surname="Phiri",Id=1,
                Addresses = new Address[]
                {
                    new Address{Line1="Number 6 Hopley Avenue, Athlone", Line2="Greendale Msasa", City="Harare"},
                    new Address{Line1="Number 7 Robson Manyika", Line2="Eastview", City="Kadoma"},
                    new Address{Line1="Number 50 Jacaranda", Line2="Westview", City="Kadoma"},
                    new Address{Line1="Number 10 Downing street", Line2="Cecil Estates", City="Kadoma"}
                },
                Dob= new DateTime(1993,8,25)
                },

                 new Applicant{Name="John", Surname="Laurie",Id=2,
                Addresses = new Address[]
                {
                    new Address{Line1="Howickvale Estate", Line2="Concession", City="Mazowe"},
                    new Address{Line1="Ivado Farm", Line2="Ivado", City="Mutorashanga"}
                },
                Dob= new DateTime(1998,6,5)
                },

                 new Applicant{Name="Firimbi", Surname="Hamsa",Id=3,
                Addresses = new Address[]
                {
                    new Address{Line1="10 Somalia", Line2="Somali", City="Somalia City"},
                    new Address{Line1="22 Gerezani", Line2="Segerea", City="Dar Es Salaam"}
                },
                Dob= new DateTime(1968,7,9)
                }


            };

            await context.Applicants.AddRangeAsync(applicants);
           await  context.SaveChangesAsync();
        }
    }
}
