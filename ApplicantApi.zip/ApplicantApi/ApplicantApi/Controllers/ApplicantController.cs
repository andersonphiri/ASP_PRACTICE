﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ApplicantApi.Models;
using ApplicantApi.Data;
using Microsoft.EntityFrameworkCore;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace ApplicantApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ApplicantController : ControllerBase
    {
        private readonly ApplicantContext _context;

        public ApplicantController(ApplicantContext context)
        {
            _context = context;
            if (_context.Applicants.Count() == 0)
            {
                DbInitializer.Initialize(_context);
            }
        }



        // GET: api/<controller>
        [HttpGet]
        public async Task<IEnumerable<Applicant>> GetApplicants()
        {
            return await _context.Applicants.Include(a=>a.Addresses.Where(ad=>ad.Id==a.Id)).ToListAsync();
        }

        // GET api/<controller>/5
        [HttpGet("{id}")]
        public string Get(int id)
        {
            return "value";
        }

        // POST api/<controller>
        [HttpPost]
        public void Post([FromBody]string value)
        {
        }

        // PUT api/<controller>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/<controller>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
