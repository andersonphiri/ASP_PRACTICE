﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Hosting.WindowsServices;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.DependencyInjection;

namespace ApplicantApi.Helpers
{
    internal class CustomWebHostService : WebHostService
    {
        private readonly ILogger _logger;
        public CustomWebHostService(IWebHost host) : base(host)
        {
            _logger = host.Services.GetRequiredService<ILogger<CustomWebHostService>>();
        }
        //overriding events methods
        protected override void OnStarting(string[] args)
        {
            _logger.LogInformation($"Hello. The OnStarting() Event Invoked. Service is now starting and Time is: {DateTime.Now.ToString()}");
            base.OnStarting(args);  
        }

        protected override void OnStarted()
        {
            _logger.LogInformation($"Hello. The OnStarted() Event Invoked. Service has started successfully and Time is: {DateTime.Now.ToString()}");

            base.OnStarted();   
        }

        protected override void OnStopping()
        {
            _logger.LogInformation($"Hello. The OnStopping() Event Invoked. Service is attempting to stop now and Time is: {DateTime.Now.ToString()}");

            base.OnStopping();
        }

        protected override void OnStopped()
        {
            _logger.LogInformation($"Hello. The OnStopped() Event Invoked. Service has stopped successfully now and Time is: {DateTime.Now.ToString()}");

            base.OnStopped();
        }
    }
}
