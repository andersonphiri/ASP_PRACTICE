﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using ApplicantApi.Data;
using Microsoft.Extensions.DependencyInjection;
using ApplicantApi.Helpers;
using System.Diagnostics;

namespace ApplicantApi
{
    public class Program
    {
        public  static void Main(string[] args)
        {
            //the isService and related variables will be used when publishing the project to be a windows service
            var isService = !(Debugger.IsAttached || args.Contains("--console"));

            if (isService)
            {
                var pathToExe = Process.GetCurrentProcess().MainModule.FileName;
                var pathToRoot = Path.GetDirectoryName(pathToExe);
                Directory.SetCurrentDirectory(pathToRoot);
            }
            var host = CreateWebHostBuilder(args).Build();//.Run();
                                                         
            //initialise database
                                                          
            // using (var scope = host.Services.CreateScope())
                                                          // {
            var scope = host.Services.CreateScope();
                var services = scope.ServiceProvider;
                try
                {
                    var context = services.GetRequiredService<ApplicantContext>();
                    DbInitializer.Initialize(context);
                }
                catch (Exception e)
                {
                    var logger = services.GetRequiredService<ILogger<Program>>();
                    logger.LogError(e, "An error occured while seeding the database");
                    //throw;
                } 

            //}
            var builderForService = CreateWebHostBuilder(args.Where(a => a != "--console").ToArray());
            var hostForService = builderForService.Build();

            if (isService)
            {
                hostForService.RunAsCustomService();
            }
            else
            {
                 host.RunAsync();
            }
        }

        public static IWebHostBuilder CreateWebHostBuilder(string[] args) =>
            WebHost.CreateDefaultBuilder(args)
            .ConfigureLogging((hostingContext,logging)=>logging.AddEventLog())
                .UseStartup<Startup>();
    }
}
