﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ApplicantApi.Models
{
    public class Applicant
    {
        //public Applicant()
        //{
        //    this.Address = new HashSet<Address>();
        //}
        public long Id { get; set; }
        public string Name { get; set; }
        public string Surname { get; set; }
        public DateTime Dob { get; set; }
        public virtual ICollection<Address> Addresses { get; set; }


    }
}
